﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AuthenticationProject.Models
{
    public class Employee
    {
        [Key]
        
        public int empid { get; set; }

        [Required]
        public string ename { get; set; }
        [Required]
        public string location { get; set; }

        [EmailAddress]
        [Required]
        public string email { get; set; }
    }
}
