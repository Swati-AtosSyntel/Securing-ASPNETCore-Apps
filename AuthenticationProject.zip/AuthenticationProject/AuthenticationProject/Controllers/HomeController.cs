﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthenticationProject.Models;
using Microsoft.AspNetCore.Mvc;

namespace AuthenticationProject.Controllers
{
    public class HomeController : Controller
    {
        private readonly IEmployeeRepository employeeRepository;

        public HomeController(IEmployeeRepository employeeRepository)
        {
            this.employeeRepository = employeeRepository;
        }
        public IActionResult Index()
        {
            return View(employeeRepository.GetEmployees());
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Employee e)
        {
            if(ModelState.IsValid)
            {
                employeeRepository.AddNewEmployee(e);
                return View("Index", employeeRepository.GetEmployees());
            }
            return View();
        }
    }
}