﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuthenticationProject.Models
{
    public class SQLEmployeeRepository : IEmployeeRepository
    {
        private readonly AppDBContext context;

        public SQLEmployeeRepository(AppDBContext context)
        {
            this.context = context;
        }
        public void AddNewEmployee(Employee e)
        {
            context.employees.Add(e);
            context.SaveChanges();
        }

        public Employee GetEmployee(int id)
        {
            return context.employees.Find(id);
        }

        public List<Employee> GetEmployees()
        {
            return context.employees.ToList();
        }
    }
}
