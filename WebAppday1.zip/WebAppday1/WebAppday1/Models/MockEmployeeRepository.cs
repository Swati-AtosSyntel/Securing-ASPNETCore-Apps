﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAppday1.Models
{
    public class MockEmployeeRepository : IEmployeeRepository
    {
        List<Employee> employees = new List<Employee>();
        public void AddNewEmployee(Employee e)
        {
            employees.Add(e);

        }

        public void DeleteEmployee(int id)
        {
            Employee e = employees.Find(emp => emp.empid == id);
            if (e != null)
                employees.Remove(e);

        }

        public Employee GetEmployee(int id)
        {
            return employees.Find(emp => emp.empid == id);
        }

        public List<Employee> GetEmployees()
        {
            return employees;
        }

        public void UpdateEmployee(Employee newEmployee)
        {
            
        }
    }
}
