﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAppday1.Models
{
   public interface IEmployeeRepository
    {
        List<Employee> GetEmployees();
        Employee GetEmployee(int id);
        void AddNewEmployee(Employee e);
        void UpdateEmployee(Employee newEmployee);

        void DeleteEmployee(int id);

    }
}
