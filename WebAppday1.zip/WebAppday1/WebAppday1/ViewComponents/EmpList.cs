﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAppday1.Models;

namespace WebAppday1.ViewComponents
{
    public class EmpList:ViewComponent
    {

        public async Task<IViewComponentResult> InvokeAsync()
        {
            List<Employee> employees = new List<Employee>()
            {
                new Employee(){empid=1,ename="Swati"},
                new Employee(){empid=2,ename="Nishant"},
            };
            return View("EmpList",employees);
        }
    }
}
