﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebAppday1.Models;

namespace WebAppday1.Controllers
{
    public class HomeController : Controller
    {
        private readonly IEmployeeRepository employeeRepository;

        public HomeController(IEmployeeRepository employeeRepository)
        {
            this.employeeRepository = employeeRepository;
        }
        public IActionResult Index()
        {
            //return ViewComponent("EmpList");
            return View();
        }
        public IActionResult ShowAllEmployees()
        {
            
            return View(employeeRepository.GetEmployees());

        }

        [HttpGet]
        public IActionResult Create()
        {

            return View();

        }
        [HttpPost]
        public IActionResult Create(Employee e)
        {
            employeeRepository.GetEmployees().Add(e);
            return View("ShowAllEmployees1", employeeRepository.GetEmployees());

        }
    }
}